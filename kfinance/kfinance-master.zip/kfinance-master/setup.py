from setuptools import setup, find_packages

setup(
    name             = 'kfinance',
    version          = '0.0.01',
    description      = 'Korea Finance Data',
    author           = 'Donggeun Kwon',
    author_email     = 'donggeun.kwon@gmail.com',
    #url              = 'https://github.com/DonggeunKwon',
    #download_url     = 'https://githur.com/DonggeunKwon/kfinance/archive/1.0.tar.gz',
    install_requires = ['pandas>=0.23.0',
						'numpy>=1.14.3',
						'pandas_datareader>=0.7.0',
						'requests>=2.18.4',
						'bs4>=0.0.1',
						'tqdm>=4'],
    packages         = find_packages(exclude = ['docs', 'tests*']),
    keywords         = ['korea', 'finance'],
    python_requires  = '>=3',
    package_data     =  {
        'pyquibase' : [
            'db-connectors/sqlite-jdbc-3.18.0.jar',
            'db-connectors/mysql-connector-java-5.1.42-bin.jar',
            'liquibase/liquibase.jar'
    ]},
    zip_safe=False,
    classifiers      = [
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.2',
        'Programming Language :: Python :: 3.3',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7'
    ]
)